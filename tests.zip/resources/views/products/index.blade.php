<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Sản phẩm!</title>
</head>

<body>
    <div class="container">
        <center>
            <h2 class="my-3 text-danger">Danh sách sản phẩm</h2>
        </center>
        <table class="table table-hover table-striped">
            <thead>
                <th>STT</th>
                <th>Tên sản phẩm</th>
                <th>Danh mục</th>
                <th>Hình ảnh</th>
                <th>Giá</th>
                <th>Kho</th>
                <th>Trạng thái</th>
                <th>
                    <a href="products/add" class="btn btn-primary">Thêm mới</a>
                </th>
            </thead>
            <tbody>
                @foreach($products as $p)
                <tr>
                    <td>{{(($products->currentPage()-1)*5)+$loop->iteration}}</td>
                    <td>{{$p->name}}</td>
                    <td>{{$p->category->name}}</td>
                    <td>
                        <div style="height: 80px;">
                            <img src="http://localhost/php3/tranhuukien/storage/app/public/{{$p->image}}" alt="" height="80px">
                        </div>
                    </td>
                    <td>{{$p->price}}</td>
                    <td>{{$p->quantity}}</td>
                    <td>
                        @if($p->status == 1)
                        Còn hàng
                        @endif
                        @if($p->status == 0)
                        Hết hàng
                        @endif
                    </td>
                    <td>
                        <a href="" class="text-primary" style="text-decoration: none;">Sửa</a> |
                        <a href="" class="text-danger" style="text-decoration: none;">Xóa</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="row" style="float: right;">
            <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
                <div class="btn-group mr-2 btn-gr" role="group" aria-label="First group">
                    <?php
                    ?>
                    <?php for ($p = 1; $p <= $page; $p++) : ?>
                        <a href="products?page={{$p}}">
                            <button type="button" class="btn btn-primary mx-1">
                                <?= $p; ?>
                            </button>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        @isset($_GET["mess"])
        <div class="alert alert-info col-6" role="alert">
            {{$_GET["mess"]}}
        </div>
        @endisset
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
</body>

</html>