<table>
    <thead>
        <th>id</th>
        <th>name</th>
        <th>email</th>
    </thead>
    <tbody>
        @foreach($users as $u)
        <tr>
            <td>{{$u->id}}</td>
            <td>{{$u->name}}</td>
            <td>{{$u->email}}</td>
        </tr>
        @endforeach
    </tbody>
</table>