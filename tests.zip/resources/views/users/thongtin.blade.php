<h2>Thông tin</h2>
Tên: <?= $data['name']; ?>
<br>
Tuổi: <?= $data['age']; ?>
<br>
Giới tính :
<?php if ($data['gt'] == 1) : ?>
    Nam
<?php elseif ($data['gt'] == 2) : ?>
    Nữ
<?php else : ?>
    Khác
<?php endif; ?>
<br>
<?php if (isset($data['kh'])) : ?>
    Đã kết hôn
<?php else : ?>
    Chưa kết hôn
<?php endif; ?>