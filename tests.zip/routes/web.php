<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('user', 'HomeController@index');
Route::get('info', 'HomeController@infoForm');
Route::get('luu-info', 'HomeController@saveForm')->name('save.info'); //biệt danh cho url là save.info

Route::get('detail/{id}/{name?}', function ($id, $name = 'kiz') {
    return $id . "-" . $name;
});

Route::get('products', 'ProductController@index');
Route::get('products/add', 'ProductController@add');
Route::post('products/save-add', 'ProductController@saveAdd')->name('save-add');
