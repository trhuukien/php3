<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::orderByDesc('id')->paginate(5);
        $products->load('category');

        $count_pro = Product::all()->count();
        $page = ceil($count_pro / 5);
        return view('products.index', compact('products', 'page'));
    }

    public function add()
    {
        $categories = Category::all();
        return view('products.add', compact('categories'));
    }

    public function saveAdd(Request $req)
    {
        $data = $req->input();
        $check = Product::where('name', $data['name'])->count();

        if ($check > 0) {
            $mess = 'Tên sản phẩm đã tồn tại!';
        } elseif ($data['name'] == '') {
            $mess = 'Tên không hợp lệ!';
        } elseif ($data['cate_id'] == '') {
            $mess = 'Danh mục không hợp lệ!';
        } elseif ($data['image'] == '') {
            $mess = 'Ảnh không hợp lệ!';
        } elseif ($data['price'] <= 0) {
            $mess = 'Giá không hợp lệ!';
        } elseif ($data['quantity'] <= 0) {
            $mess = 'Số lượng không hợp lệ!';
        };
        if (isset($mess)) {
            $url = '/products?mess=' . $mess;
            return redirect($url);
        };

        $model = new Product();
        $model->fill($data);
        $model->save();

        return redirect('/products?mess=Thành công!');
    }
}
