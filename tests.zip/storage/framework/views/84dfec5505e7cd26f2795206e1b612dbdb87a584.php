<form action="<?php echo e(route('save.info')); ?>">
    <div>
        <label for="">Tên</label>
        <input type="text" name="name" id="">
    </div>
    <div>
        <label for="">Tuổi</label>
        <input type="number" name="age" id="">
    </div>
    <div>
        <label for="">Giới tính</label>
        <input type="radio" name="gt" id="" value="1"> Nam
        <input type="radio" name="gt" id="" value="2"> Nữ
        <input type="radio" name="gt" id="" value="3"> Khác
    </div>
    <div>
        <label for="">Đã kết hôn?</label>
        <input type="checkbox" name="kh" id="" value="1">
    </div>
    <div>
        <button type="submit">Submit</button>
    </div>
</form><?php /**PATH C:\xampp\htdocs\php3\tranhuukien\resources\views/users/info_form.blade.php ENDPATH**/ ?>