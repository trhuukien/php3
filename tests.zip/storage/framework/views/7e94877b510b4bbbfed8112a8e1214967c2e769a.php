<h2>Thông tin</h2>
Tên: <?php echo e($name); ?>

<br>
Tuổi: <?php echo e($age); ?><?php /**PATH C:\xampp\htdocs\php3\tranhuukien\resources\views/users/thongtin.blade.php ENDPATH**/ ?>